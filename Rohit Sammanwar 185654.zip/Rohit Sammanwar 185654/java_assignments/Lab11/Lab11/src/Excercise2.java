/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Excercise2 {

	public static void main(String[] args) {
		ExecutorService es=Executors.newSingleThreadExecutor();
		es.execute(new Runnable() {

			@Override
			public void run() {
				try {
					System.out.println("Timer Started");
					//now this will work for 10 seconds 5 loops that is total of 50 seconds
					int j = 5;
					while(j!=0) {
						for(int i=0;i<10;i++) 
						{
						System.out.println(i);
						Thread.sleep(1000);
						}
						j--;
					}
					}catch (Exception e) {
					}
			}
			
		});

	}

}
