/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */
package com.cg.eis.exception;

public class EmployeeException extends RuntimeException{
	
	public EmployeeException(String message){
		super(message);
	}
	

}
