/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */
package Exercise4pkg;

public class Exercise4 extends RuntimeException{
	public Exercise4(String msg)
	{
		super(msg);
		
	}

	}
