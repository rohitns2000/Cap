/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Exercise6 {
	public static void main(String[] args) {
		System.out.println("Enter a belated date...(yyyy-mm-dd)");
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		LocalDate prevDate = LocalDate.parse(str);
		LocalDate nowDate = LocalDate.now();
		
		Period period = Period.between(prevDate, nowDate);
		System.out.println("The Duration :");
		System.out.println("Days=   "+period.getDays());
		System.out.println("Months= "+period.getMonths());
		System.out.println("years=  "+period.getYears());
		
		
	}

}
