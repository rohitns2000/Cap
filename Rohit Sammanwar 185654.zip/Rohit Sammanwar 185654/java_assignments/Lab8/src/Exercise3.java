/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;



public class Exercise3 {
	public static void fileRead(File f) {
		String line;
		int Line=0;
		int words=0;
		int character=0;
	try {
		BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(f)));
		while ((line=br.readLine())!=null) {

			
			if(!line.equals("")) 
			{
				character+=line.length();
				String[]word=line.split(" ");
				words +=word.length;
				
			}
			Line++;	
		}
		
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	System.out.println("line "+Line);
	System.out.println("words "+words);
	System.out.println("char "+character);
	}
	
	
	public static void main(String[] args) {
		File f=new File("D:\\LABCore\\Lab8\\File.txt");
		fileRead(f);
	}

}
