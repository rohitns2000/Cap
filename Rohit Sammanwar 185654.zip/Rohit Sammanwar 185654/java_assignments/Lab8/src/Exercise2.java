/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;



public class Exercise2 {
	public static void fileRead(File f) {
		String line;
		int count =1;
	try {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
		line=br.readLine();
		
		while (line!=null) {
			System.out.println(count +" "+line);
			count++;
			line=br.readLine();
		}
	} catch (FileNotFoundException e) 
	{
		e.printStackTrace();
	} 
	catch (IOException e) 
	{
		e.printStackTrace();
	}
	
	}
	public static void main(String[] args) {
		
		File f=new File("D:\\LABCore\\Lab8\\File.txt");
		
	fileRead(f);
	
	}
}
