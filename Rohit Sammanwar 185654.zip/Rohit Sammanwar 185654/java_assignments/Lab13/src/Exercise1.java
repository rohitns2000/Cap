/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */import java.util.Scanner;
import java.lang.*;
@FunctionalInterface
interface iobj{
	public long expo(int x, int y);
}


public class Exercise1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First number:");		
		int a = sc.nextInt();
		System.out.println("Enter Second number:");
		int b = sc.nextInt();
		iobj io;
		io = (x,y)->{return ((long)Math.pow(x, y));};
		System.out.println("The Required answer is :"+io.expo(a, b));

	}

}
