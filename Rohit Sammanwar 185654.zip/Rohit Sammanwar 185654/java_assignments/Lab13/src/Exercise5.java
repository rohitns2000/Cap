/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */import java.util.Scanner;

interface Factorial{
	public int print(int num);
}

class FactImpl{
	public static int fact(int num){
		int fact=1;
		for(int i = 2; i <= num; i++)
		{
			fact = fact*i;
		}
		return fact;
	}
	
}

public class Exercise5 {
	public static void main(String[] args) {
		System.out.println("Enter A number:-");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Factorial f1 = FactImpl::fact;
		int a = f1.print(n);
		System.out.println("The Factorial Of the Number "+n+" is "+a);
	}

}
