/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */package Exercise6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@FunctionalInterface
interface greatest{
	public String findgreatest(List<Employee> a,List<Employee> b, List<Employee> c, List<Employee> d);
}

public class EmployeeService {
	public static void sumSal(List<Employee> lst1) {
	System.out.println("1.Sum of Salaries of all Employees: ");
	Double sum = lst1.stream().collect(Collectors.summingDouble(i->i.getSalary()));
	System.out.println(sum);
	System.out.println("===================================================");
	}
	public static void seniorEmployee(List<Employee> lst1) {
	System.out.println("2.Senior-most Employee Of the organization ");
	List<Employee> employees = lst1.stream()
		      .sorted((e1, e2) -> e1.getHireDate().compareTo(e2.getHireDate()))
		      .collect(Collectors.toList());
	System.out.println(employees.get(0));
	System.out.println("===================================================");
	}
	public static void deptnameAndCount(List<Employee> lst1) {
	System.out.println("3.List out department names and count of employees in each department.");
	System.out.println("Department:IT");
	List<Employee> emp1 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("IT"))).collect(Collectors.toList());
	emp1.stream().forEach(e->System.out.print(e.getFirstname()+" "+e.getLastname()+"\n"));
	System.out.println("total no of employees in department IT is: "+emp1.size());
	System.out.println("Department:HR");
	List<Employee> emp2 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("HR"))).collect(Collectors.toList());
	emp2.stream().forEach(e->System.out.print(e.getFirstname()+" "+e.getLastname()+"\n"));
	System.out.println("total no of employees in department HR is: "+emp2.size());
	System.out.println("Department:FIN");
	List<Employee> emp3 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("FIN"))).collect(Collectors.toList());
	emp3.stream().forEach(e->System.out.print(e.getFirstname()+" "+e.getLastname()+"\n"));
	System.out.println("total no of employees in department FIN is: "+emp3.size());
	System.out.println("Department:N-FIN");
	List<Employee> emp4 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("N-FIN"))).collect(Collectors.toList());
	emp4.stream().forEach(e->System.out.print(e.getFirstname()+" "+e.getLastname()+"\n"));
	System.out.println("total no of employees in department N-FIN is: "+emp4.size());
	System.out.println("===================================================");
	}
	public static void employeesWithoutDept(List<Employee> lst1) {
	System.out.println("4.Find out employees without department. ");
	lst1.stream().filter(e->(e.getDepartment()==null)).forEach(e->System.out.println(e));
	System.out.println("===================================================");
	}
	public static void employeesWithoutReport(List<Employee> lst1) {
	System.out.println("5.Find employees who didn�t report to anyone ");
	lst1.stream().filter(e->(e.getManagerId()==0)).forEach(e->System.out.println(e));
	System.out.println("===================================================");
	}
	public static void deptMaxEmployees(List<Employee> lst1) {
	System.out.println("6.Department having maximum employee");
	List<Employee> emp5 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("IT"))).collect(Collectors.toList());

	List<Employee> emp6 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("HR"))).collect(Collectors.toList());

	List<Employee> emp7 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("FIN"))).collect(Collectors.toList());

	List<Employee> emp8 = lst1.stream().filter(e->(e.getDepartment()!=null)&&(e.getDepartment().getDepartmentName().equals("N-FIN"))).collect(Collectors.toList());

	greatest g=(empl5,empl6,empl7,empl8)->{
		if((empl5.size()>empl6.size())&&(empl5.size()>empl7.size())&&(empl5.size()>empl8.size()))
		return empl5.get(0).getDepartment().getDepartmentName();
		else if((empl6.size()>empl5.size())&&(empl6.size()>empl7.size())&&(empl6.size()>empl8.size())) return empl6.get(0).getDepartment().getDepartmentName();
		else if((empl7.size()>empl6.size())&&(empl7.size()>empl5.size())&&(empl7.size()>empl8.size())) return empl7.get(0).getDepartment().getDepartmentName();
		return empl8.get(0).getDepartment().getDepartmentName();};
	System.out.println("The Department having the highest number of employees is : "+g.findgreatest(emp5, emp6, emp7, emp8));
	System.out.println("===================================================");
	}
	public static void salIncrease(List<Employee> lst1) {
	System.out.println("7.Employee full name================Employee initial salary=================Employee's incremented salary(15%)====");
	lst1.stream().forEach(e->System.out.println(e.getFirstname()+" "+e.getLastname()+" "+e.getSalary()+" "+(e.getSalary()*0.15+e.getSalary())));
	}
	
	public static void main(String[] args) {
		List<Employee> lst1 = EmployeeRepository.getData();
		sumSal(lst1);
		seniorEmployee(lst1);
		deptnameAndCount(lst1);
		employeesWithoutDept(lst1);
		employeesWithoutReport(lst1);
		deptMaxEmployees(lst1);
		salIncrease(lst1);
		
	}
	
}
