/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */package Exercise6;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class EmployeeRepository {
	public static List<Employee> getData() {
		Scanner sc = new Scanner(System.in);
		
		List<Employee> lst = new ArrayList<Employee>();
		Department d1 = new Department(101, "FIN", 1001);
		Department d2 = new Department(102, "IT", 1002);
		Department d3 = new Department(103, "HR", 1003);
		Department d4 = new Department(104, "N-FIN", 1004);
		Employee emp1 = new Employee(1001, "Sham", "Kumar", "Sham@123", "9876789372",LocalDate.parse("1998-11-02"), "Analyst1", 50000.00, 1001, d1);
		Employee emp2 = new Employee(1002, "Raut", "Singh", "Raut@1234", "9876789373",LocalDate.parse("1998-11-03"), "Analyst2", 25000.00, 1004, d4);
		Employee emp3 = new Employee(1003, "Shobit", "Sinha", "Shobit@1235", "9876789374",LocalDate.parse("1998-11-04"), "Analyst3", 15000.00, 1001, d1);
		Employee emp4 = new Employee(1004, "Khan", "Roy", "Khan@1236", "9876789375",LocalDate.parse("1998-11-05"), "Analyst4", 35000.00, 1002, d2);
		Employee emp5 = new Employee(1005, "Tika", "Katta", "Tika@1237", "9876789376",LocalDate.parse("1998-11-01"), "Analyst5",65000.00, 1002, d2);
		Employee emp6 = new Employee(1006, "Pekka", "Lovr", "LovrPeka@1237", "9899789389",LocalDate.parse("1998-12-01"), "Analyst6",85000.00, 1001, null);
		Employee emp7 = new Employee(1007, "Tommy", "Larson", "LovrPeka@1237", "9876999389",LocalDate.parse("1999-12-01"), "Analyst7",6000.00, 0, d4);
		Employee emp8 = new Employee(1008, "Kesha", "gray", "KeshaLove@1237", "9877889389",LocalDate.parse("2000-12-01"), "Analyst8",78000.00, 1004, d4);
		
		lst.add(emp1);
		lst.add(emp2);
		lst.add(emp3);
		lst.add(emp4);
		lst.add(emp5);
		lst.add(emp6);
		lst.add(emp7);
		lst.add(emp8);

		return lst;
	}

}
