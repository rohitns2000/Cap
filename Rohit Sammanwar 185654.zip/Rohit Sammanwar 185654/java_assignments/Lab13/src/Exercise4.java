/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */interface Printable{
	public void print(Object o);
}

public class Exercise4 {
	public static void meth1(Object o)
	{
		System.out.println("Static Method "+o);
	}
	public static void main(String[] args) {
		Printable p1 = Exercise4::meth1;
		p1.print("Welcome to Method Reference");
	}

}
