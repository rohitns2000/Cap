/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */import java.util.Scanner;

interface Authentication{
	boolean authenticate(String u_name,String pass);
}
public class Exercise3 {
	public static void main(String[] args) {
		System.out.println("Enter Username:-");
		Scanner sc = new Scanner(System.in);
		String u_name1 = sc.next();
		
		System.out.println("Enter Password:-");
		String pass1 = sc.next();
		
		Authentication auth;
		auth = (u_name,pass)->{
			if(u_name.equals("Rohit")&&(pass.equals("password")))
			{
				return true;
			}
			return false;
		};
		
		System.out.println("Your validation is: "+auth.authenticate(u_name1, pass1));
	}

}
