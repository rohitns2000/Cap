/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */import java.util.Scanner;

interface Format{
	public String formatString(String str);
}

public class Exercise2 {
	public static void main(String[] args) {
		System.out.println("Enter the string you want to format:");
		Scanner sc = new Scanner(System.in);
		String str1=sc.next();
		
		Format fmat;
		fmat = (str)->{String str2 =str.replace("", " ");
						return str2;
						};
		
		System.out.println("The Formatted String is:"+fmat.formatString(str1));
	}
	

}
