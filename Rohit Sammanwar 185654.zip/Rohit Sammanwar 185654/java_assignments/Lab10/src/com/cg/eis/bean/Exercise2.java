/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */package com.cg.eis.bean;

public class Exercise2 {

	public static void main(String[] args) {

		Excersise2_threadClass thc = new Excersise2_threadClass();
		Thread th=new Thread(thc);
		th.start();
	}

}
