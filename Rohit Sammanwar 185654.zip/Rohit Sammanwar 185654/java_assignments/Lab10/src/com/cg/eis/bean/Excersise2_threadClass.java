/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */package com.cg.eis.bean;

import java.util.Date;



public class Excersise2_threadClass implements Runnable{

	public void run() {
		System.out.println("Starting ");
		System.out.println("Starting date/time:"+new Date());
			try {
				System.out.println("Timer Started");
				//now this will work for 10 seconds 5 loops that is total of 50 seconds
				int j = 1;
				while(j!=0) {
					for(int i=0;i<10;i++) 
					{
					System.out.println(i);
					Thread.sleep(1000);
					}
					j--;
				}
				}catch (Exception e) {
				}
		
		System.out.println("Ending date/time:"+new Date());
	}
	}
	
	

