/*
 * 
 * 
 * 
 * Rohit Sammanwar
 * 
 * 
 */package com.cg.eis.bean;
import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread {
	FileInputStream srcfile;
	FileOutputStream targetfile;
	
	public void findFile(String s1,String s2) throws IOException
	{
		try {//try block
			
			srcfile=new FileInputStream(s1);
			targetfile=new FileOutputStream(s2);
		}
		catch (FileNotFoundException fe) 
		{
			//Exceptional handelling
			System.out.println(fe);	
			
		}
	}
	public void copyContents()throws IOException,InterruptedException
	{
		try
		{
			int i=srcfile.read();
			int charcount=0;
			
			while (i!=-1) {
				charcount++;
				if(charcount==10)
				{
					System.out.println("10 characters are copied");
					//resetting character count
					charcount=0;
					//making the thread sleep for 5 seconds
					Thread.sleep(5000);
				}
				targetfile.write(i);
				i=srcfile.read();
			}
		}
		catch (IOException ioe) {
			System.out.println(ioe);
			throw ioe;
		}
	finally {
		if(srcfile!=null)
		{
			srcfile.close();
		}
		if(targetfile!=null)
		{
			targetfile.close();
		}
	}

}}
